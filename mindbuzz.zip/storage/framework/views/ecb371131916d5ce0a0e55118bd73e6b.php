


<?php $__env->startSection('content'); ?>
    <div class="nk-app-root">
        <div class="nk-main ">
            <?php echo $__env->make('dashboard.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="nk-wrap ">
                <?php echo $__env->make('dashboard.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12 margin-tb mb-4">
                                <div class="pull-left">
                                    <h2> Show Role
                                        <div class="float-end">
                                            <a class="btn btn-primary" href="<?php echo e(route('roles.index')); ?>"> Back</a>
                                        </div>
                                    </h2>
                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-xs-12 mb-3">
                                <div class="form-group">
                                    <strong>Name:</strong>
                                    <?php echo e($role->name); ?>

                                </div>
                            </div>
                            <div class="col-xs-12 mb-3">
                                <div class="form-group">
                                    <strong>Permissions:</strong>
                                    <?php if(!empty($rolePermissions)): ?>
                                        <?php $__currentLoopData = $rolePermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <label class="label label-secondary text-dark"><?php echo e($v->name); ?>,</label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mindbuzz\resources\views/dashboard/roles/show.blade.php ENDPATH**/ ?>