<link rel="shortcut icon" href="<?php echo e(asset('images/favicon.png')); ?>">
<title>Dashboard | LMS | DashLite Admin Template</title>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/dashlitee5ca.css?ver=3.2.3')); ?>">
<link id="skin-default" rel="stylesheet" href="<?php echo e(asset('assets/css/themee5ca.css?ver=3.2.3')); ?>">
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-91615293-4"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());
    gtag('config', 'UA-91615293-4');
</script>
<?php /**PATH C:\laragon\www\mindbuzz\resources\views/dashboard/layouts/header.blade.php ENDPATH**/ ?>