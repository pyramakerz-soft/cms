<script src="<?php echo e(asset('assets/js/bundlee5ca.js?ver=3.2.3')); ?>"></script>
<script src="<?php echo e(asset('assets/js/scriptse5ca.js?ver=3.2.3')); ?>"></script>
<script src="<?php echo e(asset('assets/js/demo-settingse5ca.js?ver=3.2.3')); ?>"></script>
<script src="<?php echo e(asset('assets/js/charts/chart-lmse5ca.js?ver=3.2.3')); ?>"></script>
<?php /**PATH C:\laragon\www\mindbuzz\resources\views/dashboard/layouts/scripts.blade.php ENDPATH**/ ?>