<?php $__env->startSection('content'); ?>

    <div class="content-wrapper p-3">
        <div class="row border-bottom mb-4">
            <div class="col-12 col-sm-9">
                <nav aria-label="breadcrumb" class="mt-2 ">
                    <ol class="breadcrumb">
                        

                    </ol>
                </nav>
            </div>
            <div class="col-12 col-sm-3 text-end">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles create')): ?>
                    <a class="btn btn-primary" href="<?php echo e(route('roles.create')); ?>"><?php echo e(trans('admin.create')); ?></a>
                <?php endif; ?>


                <!-- <?php if(Request::has('trashed')): ?>
    <a class="btn btn-secondary" href="<?php echo e(route('admin.roles.index')); ?>"><?php echo e(trans('admin.items')); ?></a>
<?php else: ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles forceDelete')): ?>
        <a class="btn btn-secondary" href="<?php echo e(route('admin.roles.index')); ?>?trashed"><?php echo e(trans('admin.deleted_items')); ?></a>
    <?php endif; ?>
    <?php endif; ?> -->

            </div>
        </div>

        <div class="row">

            <div class="card">
                <div class="card-body">
                    <?php if(Session::has('message')): ?>
                        <div class="p-1">
                            <div class="alert alert-<?php echo e(Session::get('status')); ?>" role="alert">
                                <div class="alert-body">
                                    <?php echo e(Session::get('message')); ?>

                                </div>
                            </div>
                        </div>
                    <?php endif; ?>


                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <div class="alert-body">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    <?php endif; ?>

                    
                    <div class="row">
                        <div class="mb-2">
                            
                        </div>
                        <div class="mb-2">
                            <ul class="list-inline">
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li
                                        class="list-inline-item <?php echo e(in_array($value->id, $rolePermissions) ? 'border border-primary text-primary' : 'border '); ?> p-2 rounded-3 m-2">
                                        

                                        <?php echo e(Str::of($value->name)->swap([
                                            'view' => 'مشاهدة',
                                            'create' => 'إنشاء',
                                            'edit' => 'تعديل',
                                            'delete' => 'حذف',
                                            'forceDelete' => 'حذف فعلي',
                                            'restore' => 'إرجاع',
                                            'admin' => 'الإدارة - ',
                                            'profile' => 'الملف الشخصي -',
                                            'language' => 'اللغة  -',
                                            'forms' => 'النماذج  -',
                                            'fields' => 'الحقول  -',
                                            'partners' => 'الجهات  -',
                                            'projects' => 'المشاريع  -',
                                            'dnas' => 'dnas  -',
                                            'flags' => 'التعقيبات  -',
                                            'pages' => 'الصفحات  -',
                                            'settings' => 'الإعدادات  -',
                                            'statuses' => 'الحالات  -',
                                            'users' => 'الاعضاء  -',
                                            'subjects' => 'المجالات  -',
                                            'levels' => 'المستويات  -',
                                            'types' => 'انواع المعلومة  -',
                                            'kinds' => 'أنواع الجهات  -',
                                            'objectives' => 'الاهداف التعليمية  -',
                                            'dna-types' => 'انواع DNA  -',
                                            'beneficiaries' => 'الفئات المستفيدة  -',
                                            'hints' => 'التعليمات  -',
                                            'covers' => 'الفئات التعليمية المستفيدة  -',
                                            'domains' => 'نطاقات المشروع  -',
                                            'rubrics' => 'المعايير  -',
                                            'ideatypes' => 'انواع افكار DNA   -',
                                            'referencetypes' => 'انواع المراجع  -',
                                            'design-levels' => 'مستويات التصميم  -',
                                            'objective-levels' => 'مستويات الاهداف التعليمية  -',
                                            'inquiries' => 'الاستفسارات  -',
                                            'replays' => 'تعليقات المساحات  -',
                                            'roles' => 'الصلاحيات  -',
                                            'notifications' => 'التنبيهات  -',
                                        ])); ?>

                                        </label>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="mb-3 col-12 offset-0 col-sm-3 offset-sm-9">
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary"><?php echo e(trans('admin.submit')); ?> </button>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mindbuzz\resources\views/dashboard/roles/edit.blade.php ENDPATH**/ ?>