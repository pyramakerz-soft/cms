
<?php $__env->startSection('content'); ?>
    <div class="nk-app-root">
        <div class="nk-main ">
            <?php echo $__env->make('dashboard.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="nk-wrap ">
                <?php echo $__env->make('dashboard.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="nk-block-head nk-block-head-sm">
                                    <div class="nk-block-between">
                                        <div class="nk-block-head-content">
                                            <h3 class="nk-block-title page-title">Students</h3>
                                        </div>
                                        <div class="nk-block-head-content">
                                            <div class="toggle-wrap nk-block-tools-toggle"><a href="#"
                                                    class="btn btn-icon btn-trigger toggle-expand me-n1"
                                                    data-target="more-options"><em class="icon ni ni-more-v"></em></a>
                                                <div class="toggle-expand-content" data-content="more-options">
                                                    <div class="row">
                                                        <div class="col-12 mb-4">
                                                            <form action="<?php echo e(route('import.users')); ?>" method="POST"
                                                                enctype="multipart/form-data">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="row">
                                                                    <div class="col-7">
                                                                        <div class="form-group">
                                                                            
                                                                            <input type="file" name="file"
                                                                                class="form-control" required>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-5">
                                                                        <button type="submit"
                                                                            class="btn btn-primary">Import
                                                                            Users</button>
                                                                    </div>
                                                                </div>


                                                            </form>
                                                        </div>
                                                    </div>
                                                    <form method="GET" action="<?php echo e(route('students.index')); ?>">
                                                        <ul class="nk-block-tools g-3">


                                                            <li>
                                                                <div class="drodown">
                                                                    <a href="#"
                                                                        class="dropdown-toggle dropdown-indicator btn btn-outline-light btn-white"
                                                                        data-bs-toggle="dropdown">School</a>
                                                                    <div class="dropdown-menu dropdown-menu-end">
                                                                        <ul class="link-list-opt no-bdr">
                                                                            <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <li>
                                                                                    <a href="#"
                                                                                        onclick="document.querySelector('input[name=school]').value = '<?php echo e($school->id); ?>'; document.querySelector('form').submit();">
                                                                                        <span><?php echo e($school->name); ?></span>
                                                                                    </a>
                                                                                </li>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </ul>
                                                                        <input type="hidden" name="school"
                                                                            value="<?php echo e(request('school')); ?>">
                                                                    </div>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="drodown">
                                                                    <a href="#"
                                                                        class="dropdown-toggle dropdown-indicator btn btn-outline-light btn-white"
                                                                        data-bs-toggle="dropdown">Program</a>
                                                                    <div class="dropdown-menu dropdown-menu-end">
                                                                        <ul class="link-list-opt no-bdr">
                                                                            <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <li>
                                                                                    <a href="#"
                                                                                        onclick="document.querySelector('input[name=program]').value = '<?php echo e($program->id); ?>'; document.querySelector('form').submit();">
                                                                                        <span><?php echo e($program->name); ?></span>
                                                                                    </a>
                                                                                </li>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </ul>
                                                                        <input type="hidden" name="program"
                                                                            value="<?php echo e(request('program')); ?>">
                                                                    </div>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="drodown">
                                                                    <a href="#"
                                                                        class="dropdown-toggle dropdown-indicator btn btn-outline-light btn-white"
                                                                        data-bs-toggle="dropdown">Grade</a>
                                                                    <div class="dropdown-menu dropdown-menu-end">
                                                                        <ul class="link-list-opt no-bdr">
                                                                            <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <li>
                                                                                    <a href="#"
                                                                                        onclick="document.querySelector('input[name=grade]').value = '<?php echo e($grade->id); ?>'; document.querySelector('form').submit();">
                                                                                        <span><?php echo e($grade->name); ?></span>
                                                                                    </a>
                                                                                </li>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </ul>
                                                                        <input type="hidden" name="grade"
                                                                            value="<?php echo e(request('grade')); ?>">
                                                                    </div>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="drodown">
                                                                    <a href="#"
                                                                        class="dropdown-toggle dropdown-indicator btn btn-outline-light btn-white"
                                                                        data-bs-toggle="dropdown">Class</a>
                                                                    <div class="dropdown-menu dropdown-menu-end">
                                                                        <ul class="link-list-opt no-bdr">
                                                                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <li>
                                                                                    <a href="#"
                                                                                        onclick="document.querySelector('input[name=group]').value = '<?php echo e($class->id); ?>'; document.querySelector('form').submit();">
                                                                                        <span><?php echo e($class->name); ?></span>
                                                                                    </a>
                                                                                </li>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </ul>

                                                                        <input type="hidden" name="group"
                                                                            value="<?php echo e(request('group')); ?>">
                                                                    </div>
                                                                </div>
                                                            </li>
                                                            <li class="nk-block-tools-opt">
                                                                <button type="submit"
                                                                    class="btn btn-primary">Filter</button>
                                                            </li>
                                                        </ul>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="nk-block">
                                    <div class="card">
                                        <div class="card-inner-group">
                                            <div class="card-inner p-0">
                                                <div class="nk-tb-list nk-tb-ulist">
                                                    <div class="nk-tb-item nk-tb-head">

                                                        <div class="nk-tb-col"><span class="sub-text">Student</span>
                                                        </div>
                                                        <div class="nk-tb-col tb-col-mb"><span
                                                                class="sub-text d-lg-flex d-none">School</span></div>
                                                        <div class="nk-tb-col tb-col-md"><span class="sub-text">Phone</span>
                                                        </div>
                                                        <div class="nk-tb-col tb-col-lg"><span class="sub-text">Grade</span>
                                                        </div>
                                                        <div class="nk-tb-col tb-col-lg"><span
                                                                class="sub-text">Program</span></div>

                                                    </div>
                                                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="nk-tb-item">

                                                            <div class="nk-tb-col"><a href="students-details.html">
                                                                    <div class="user-card">
                                                                        <div class="user-avatar"><img
                                                                                src="../images/avatar/a-sm.jpg"
                                                                                alt="">
                                                                        </div>
                                                                        <div class="user-info"><span
                                                                                class="tb-lead"><?php echo e($student->name); ?> <span
                                                                                    class="dot dot-warning d-md-none ms-1"></span></span><span><?php echo e($student->email); ?></span>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </div>
                                                            <div class="nk-tb-col tb-col-mb"><span
                                                                    class="tb-lead d-lg-flex d-none"><?php echo e($student->school->name); ?>

                                                                </span>
                                                                <div class="d-lg-flex d-none">

                                                                </div>
                                                            </div>
                                                            <div class="nk-tb-col tb-col-md">
                                                                <span><?php echo e($student->phone); ?></span>
                                                            </div>
                                                            <div class="nk-tb-col tb-col-lg">
                                                                <span><?php echo e($student->details[0]->stage->name); ?></span>
                                                            </div>
                                                            <div class="nk-tb-col tb-col-mb"><span
                                                                    class="tb-lead d-lg-flex d-none"></span>
                                                                <div class="d-lg-flex d-none">
                                                                    <div class="drodown"><a href="#"
                                                                            class="dropdown-toggle pt-1 text-info"
                                                                            data-bs-toggle="dropdown"> <span>View
                                                                                More</span> </a>

                                                                        <div class="dropdown-menu dropdown-menu-start">
                                                                            <ul class="link-list-opt no-bdr p-3">
                                                                                <?php $__currentLoopData = $student->userCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <li class="tb-lead p-1">
                                                                                        <?php echo e($course->program->course->name ?? 'N/A'); ?>

                                                                                        <?php if(!$loop->last): ?>
                                                                                            ,
                                                                                        <?php endif; ?>
                                                                                    </li>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="nk-tb-col nk-tb-col-tools text-end">
                                                                <div class="dropdown">
                                                                    <a href="#"
                                                                        class="btn btn-xs btn-outline-light btn-icon dropdown-toggle"
                                                                        data-bs-toggle="dropdown" aria-expanded="false">
                                                                        <em class="icon ni ni-more-h"></em>
                                                                    </a>
                                                                    <div class="dropdown-menu dropdown-menu-end">
                                                                        <ul class="link-list-opt no-bdr">
                                                                            <li><a
                                                                                    href="<?php echo e(route('students.edit', $student->id)); ?>"><em
                                                                                        class="icon ni ni-edit"></em><span>Edit</span></a>
                                                                            </li>
                                                                            <li>
                                                                                <a href="#"
                                                                                    onclick="event.preventDefault(); document.getElementById('delete-form-<?php echo e($student->id); ?>').submit();"><em
                                                                                        class="icon ni ni-trash"></em><span>Delete</span></a>
                                                                            </li>
                                                                            <form id="delete-form-<?php echo e($student->id); ?>"
                                                                                action="<?php echo e(route('students.destroy', $student->id)); ?>"
                                                                                method="POST" style="display: none;">
                                                                                <?php echo csrf_field(); ?>
                                                                                <?php echo method_field('DELETE'); ?>
                                                                            </form>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                                                </div>
                                            </div>
                                        </div>

                                        <div class="card-inner">
                                            <div class="nk-block-between-md g-3">
                                                <?php echo $students->links(); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php echo $__env->make('dashboard.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mindbuzz\resources\views/dashboard/students/index.blade.php ENDPATH**/ ?>