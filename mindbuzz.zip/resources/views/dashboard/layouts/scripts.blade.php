<script src="{{ asset('assets/js/bundlee5ca.js?ver=3.2.3') }}"></script>
<script src="{{ asset('assets/js/scriptse5ca.js?ver=3.2.3') }}"></script>
<script src="{{ asset('assets/js/demo-settingse5ca.js?ver=3.2.3') }}"></script>
<script src="{{ asset('assets/js/charts/chart-lmse5ca.js?ver=3.2.3') }}"></script>
