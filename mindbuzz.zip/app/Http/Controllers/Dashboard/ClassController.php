<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\Group;
use App\Models\Program;
use App\Models\School;
use App\Models\Stage;
use Illuminate\Http\Request;

class ClassController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $classes = Group::all();
        return view('dashboard.class.index', compact("classes"));

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $schools = School::all();
        $programs = Program::all();
        $stages = Stage::all();

        return view('dashboard.class.create', compact('schools', 'programs', 'stages'));

    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'sec_name' => 'nullable|string|max:255',
            'school_id' => 'required|exists:schools,id',
            'stage_id' => 'required|exists:stages,id',
            'program_id' => 'required|exists:programs,id',

        ]);

        $class = Group::create([
            'name' => $request->name,
            'sec_name' => $request->sec_name,
            'school_id' => $request->school_id,
            'stage_id' => $request->stage_id,
            'program_id' => $request->program_id,
        ]);

        return redirect()->route('classes.create')->with('success', 'Class created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $class = Group::findOrFail($id);
        $schools = School::all();
        $programs = Program::all();
        $stages = Stage::all();
        return view("dashboard.class.edit", compact(["class", 'schools', 'stages', 'programs']));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'sec_name' => 'nullable|string|max:255',
            'school_id' => 'required|exists:schools,id',
            'stage_id' => 'required|exists:stages,id',
            'program_id' => 'required|exists:programs,id',

        ]);

        $class = Group::findOrFail($id);
        $class->update([
            'name' => $request->name,

            'school_id' => $request->school_id,
            'sec_name' => $request->sec_name,
            'stage_id' => $request->stage_id,
            'program_id' => $request->program_id,
        ]);



        return redirect()->route('classes.index')->with('success', 'Class updated successfully.');

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $class = Group::findOrFail($id);

        $class->delete();

        return redirect()->route('classes.index')->with('success', 'Class deleted successfully.');
    }
}